﻿# SILENTWARE: CS2

## Reminder
- this cheat is a free for users.
- the leak of any function or the source code itself is punishable by deletion from the repository and blocking in all social networks of the project.

  [✓] ESP - basic esp feature like: name, hp, armor... (comes with interactive menu preview, not draggable)
  
  [✓] CHAMS - basic chams system

  [✓] WORLD - basic world modulation (colors, effects)

  [✓] LOCAL VISUALS - basic functions. FOV, XYZ, ThirdPerson and more.

  [✓] MODELCHANGER - u love anime chan <3 ?
  
  [✓] RAGEBOT - good aimbot system for rage game

  [✓] ANTI-AIMS - antihit system. It's so good function if u play HvH
