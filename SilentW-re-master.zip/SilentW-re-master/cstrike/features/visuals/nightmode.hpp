#pragma once

#include "../../common.h"


namespace F::VISUALS::NIGHTMODE
{
	void Draw();
}
