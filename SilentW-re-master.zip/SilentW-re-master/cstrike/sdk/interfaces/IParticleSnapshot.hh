#pragma once

class IParticleSnapshot
{

};
